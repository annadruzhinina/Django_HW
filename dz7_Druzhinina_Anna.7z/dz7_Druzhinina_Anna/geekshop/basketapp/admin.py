from django.contrib import admin

from basketapp.models import Basket

admin.site.register(Basket)
