from django.shortcuts import render, HttpResponseRedirect, get_object_or_404
import logging

from basketapp.models import Basket
from mainapp.models import Product


def basket(request):
    content = {}
    return render(request, 'basketapp/basket.html', content)


def basket_add(request, pk):
    logger = logging.getLogger('geekshop.basketapp.add')

    product = get_object_or_404(Product, pk=pk)
    basket_item = Basket.objects.filter(user=request.user, product=product).first()

    if not basket_item:
        basket_item = Basket(user=request.user, product=product)

    basket_item.quantity += 1
    basket_item.save()

    logger.info('Basket Add::'+str(pk))

    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
    # content = {}
    # return render(request, 'basketapp/basket.html', content)

def basket_remove(request):
    content = {}
    return render(request, 'basketapp/basket.html', content)
