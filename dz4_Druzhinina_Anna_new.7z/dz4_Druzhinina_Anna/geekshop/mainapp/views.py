import json
import os
from django.shortcuts import render
import datetime

from django.template.defaultfilters import title

from geekshop.settings import BASE_DIR
# Create your views here.
from .models import ProductCategory, Product


def main(request):
    title = 'главная'
    products = Product.objects.all()[:4]
    content ={'title': title, 'products': products}
    return render(request, 'mainapp/index.html', content)


def products(request, pk=None):
    print(pk)
    title = 'продукты'
    links_menu = ProductCategory.objects.all()
    same_products = Product.objects.all()

    context = {'title': title,'links_menu': links_menu,'same_products': same_products}
    return render(request, 'mainapp/products.html', context)

def contact(request):
    title = 'о нас'
    visit_date = datetime.datetime.now()
    locations = []
    contacts_file_path = os.path.join(BASE_DIR, 'contacts.json')
    if os.path.exists(contacts_file_path):
        with open(contacts_file_path,encoding="utf8") as contacts_file:
            locations = json.loads(contacts_file.read())
    context = {'title': title, 'vivsit_date': visit_date, 'locations': locations}
    return render(request, 'mainapp/contact.html', context)

    ## return render(request, 'mainapp/contact.html')
